export default interface MenuCategory {
  id: number;
  hex: string;
  price: number;
  name: string;
}