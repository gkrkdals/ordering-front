export default interface OrderCategory {
  id: number;
  status: number;
  name: string;
  hex: string;
}