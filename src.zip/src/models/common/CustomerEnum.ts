export enum CustomerEnum {
  InstantPayment = 3,
  PayAfterDisposal,
  BankbookPayment,
  PayPerWeek,
  PayPerMonth,
}