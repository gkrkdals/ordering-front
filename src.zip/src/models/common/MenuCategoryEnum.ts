export enum MenuCategoryEnum {
  Transparent = 1,
  Blue,
  Green,
  Custom
}