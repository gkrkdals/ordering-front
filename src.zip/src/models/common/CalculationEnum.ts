export enum CalculationEnum {
  Daily = 1,
  Weekly,
  Monthly,
  ByMenu,
  ByCustomer,
}