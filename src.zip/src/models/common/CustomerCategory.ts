export interface CustomerCategory {
  id: number;
  name: string;
  hex: string;
}