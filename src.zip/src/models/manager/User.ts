export default interface User {
  id: number;
  username: string;
  nickname: string;
  permission: number;
  time: string;
}