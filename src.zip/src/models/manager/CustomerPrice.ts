
export interface CustomerPrice {
  id: number;
  customer: number;
  category: number;
  price: number;
}