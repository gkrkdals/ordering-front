export interface Column {
  key: string;
  name: string;
}