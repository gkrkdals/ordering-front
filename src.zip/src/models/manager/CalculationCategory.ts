export interface CalculationCategory {
  id: number;
  name: string;
}