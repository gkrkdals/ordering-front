export interface OrderHistory {
  status: string;
  time: string;
}