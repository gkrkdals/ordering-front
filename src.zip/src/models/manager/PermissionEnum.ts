export enum PermissionEnum {
  Manager = 1,
  Rider,
  Cook,
  Client = 9
}