export interface Settings {
  id: number;
  big: number;
  sml: number;
  name: string;
  value: number;
  stringValue: string;
}