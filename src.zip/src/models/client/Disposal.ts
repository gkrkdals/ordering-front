export interface Disposal {
  order_code: number;
  menu: number;
  menu_name: string;
  status: number;
  location: string | null;
}