import Menu from "@src/models/common/Menu.ts";

export default interface SelectedMenu {
  menu: Menu;
  request: string;
}