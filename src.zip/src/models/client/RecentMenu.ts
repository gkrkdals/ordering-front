import Menu from "@src/models/common/Menu.ts";

export interface RecentMenu extends Menu {
  time: string;
}