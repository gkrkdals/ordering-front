export interface OrderSummary {
  id: number;
  status: number;
  statusName: string;
  menu: number;
  menuName: string;
}